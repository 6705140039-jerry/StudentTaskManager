---
name: Academic Focus System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#464554'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#777586'
  outline-variant: '#c7c4d7'
  surface-tint: '#5148d7'
  primary: '#2a14b4'
  on-primary: '#ffffff'
  primary-container: '#4338ca'
  on-primary-container: '#c1beff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#7b0020'
  on-tertiary: '#ffffff'
  tertiary-container: '#a6002f'
  on-tertiary-container: '#ffb0b4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#100069'
  on-primary-fixed-variant: '#372abf'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#ffdada'
  tertiary-fixed-dim: '#ffb3b6'
  on-tertiary-fixed: '#40000c'
  on-tertiary-fixed-variant: '#920028'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
  badge-label:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
---

## Brand & Style

The design system is engineered for academic rigor, calm focus, and deliberate momentum. Built for scholars, researchers, and university students navigating complex course loads, exams, and milestones, the interface prioritizes intellectual clarity over fleeting gamification. It balances the structure of traditional academic planners with the precision of high-performance workflow tooling.

### Visual Style
- **Modern Focused Functionalism:** High information clarity, precise micro-details, tactile controls, and disciplined visual noise.
- **Physical Desk Metaphor:** Warm, grounded slate undertones evoke heavyweight study cards, precision stationery, and slate desktops, balanced against deep digital indigo surfaces.
- **Intentional Contrast:** Monochrome foundations allow functional states—emerald completions, amber warnings, and coral emergencies—to register instantly without inducing cognitive fatigue.

## Colors

The palette establishes an ordered academic environment. Indigo acts as the focal anchor for primary navigation, critical interactive states, and active academic terms. Neutral tones rely on warm slate rather than sterile cool grays, providing sustained visual comfort during long study sessions.

### Semantic Mapping
- **Primary (`#4338CA` - Deep Indigo):** Active tabs, primary buttons, active course markers, focus session timers.
- **Secondary (`#059669` - Emerald):** Completed tasks, grade targets achieved, verified citations, submission confirmations.
- **Tertiary (`#E11D48` - Coral Rose) & Amber (`#D97706`):** Critical deadlines due in <24 hours, missed benchmarks, overdue alerts (`#E11D48`); approaching milestones (24–72 hours) and warnings (`#D97706`).
- **Surface & Neutrals:**
  - Base Canvas: `#F8FAFC` (Warm Paper White)
  - Surface Raised: `#FFFFFF` (Card Stock)
  - Surface Recessed: `#F1F5F9` (Muted Wells & Segment Tracks)
  - Border Subtle: `#E2E8F0`
  - Border Strong: `#CBD5E1`
  - Text Primary: `#0F172A` (Slate Ink)
  - Text Secondary: `#475569` (Subtle Ink)
  - Text Muted: `#94A3B8` (Metadata Slate)

## Typography

Typography balances clean structural hierarchy with scientific precision. 

- **Headlines (Plus Jakarta Sans):** Delivers contemporary warmth and legibility for dashboard headers, course titles, and section dividers.
- **Body & Controls (Inter):** Neutral, hyper-legible workhorse optimized for reading assignments, syllabus outlines, and dense notes.
- **Metadata & Data Points (JetBrains Mono):** Reserved for technical markers: Task IDs (e.g., `CS-204-A1`), countdown timers, GPA metrics, and timestamps.

## Layout & Spacing

A 12-column fluid grid orchestrates wide-screen environments, consolidating down to 4 columns on mobile viewports. Layouts utilize modular cards and fixed vertical pacing driven by a consistent 4px/8px rhythm.

### Grid Breakpoints
- **Mobile (< 768px):** 4 columns, 16px gutter, 16px outer margin. Navigational filters and segmented views shift into horizontally scrollable rails.
- **Tablet (768px – 1024px):** 8 columns, 20px gutter, 24px outer margin. Side-by-side split layouts for calendar/agenda workflows.
- **Desktop (> 1024px):** 12 columns, 24px gutter, 40px outer margin, max content boundary capped at 1360px for reading comfort.

## Elevation & Depth

Visual hierarchy uses **tonal layer separation combined with tactile ambient drop shadows**. Surfaces appear physical, reminiscent of stacked card stock and matte desk accessories.

- **Level 0 (Canvas):** `#F8FAFC` flat surface.
- **Level 1 (Default Cards & Containers):** `#FFFFFF` surface with a 1px border (`#E2E8F0`) and subtle offset shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Hovered Cards, Segmented Controls, Popovers):** `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
- **Level 3 (Modals & Command Palettes):** `#FFFFFF` surface floating over a 40% slate overlay (`rgba(15, 23, 42, 0.4)`), elevated by `0 20px 25px -5px rgba(15, 23, 42, 0.1), 0 8px 10px -6px rgba(15, 23, 42, 0.08)`.
- **Tactile Depressed State:** Interactive cards and tactile buttons shift on `:active` by translating `+1px` vertically and reducing shadow depth to zero to mimic physical engagement.

## Shapes

The interface embraces a disciplined **Soft (`1`)** shape language:
- Base elements (buttons, inputs, task cards, badges) employ `0.375rem` to `0.5rem` (`rounded-md` / `rounded-lg`).
- Status pills, completion badges, and segmented toggles use full-radius containment (`9999px` pill) to distinctly contrast against rectangular content surfaces.
- Segmented control tracks retain `0.5rem` radiuses while inner active capsules match at `0.375rem`.

## Components

### Task Cards
- Built on Level 1 elevation with a base `#FFFFFF` background and a `#E2E8F0` border.
- Cards host a fixed metadata row featuring:
  - **Task ID:** Styled with `label-mono-sm` in `#64748B` over a `#F1F5F9` micro-container.
  - **Due Date Indicator:** Accompanied by a calendar glyph; tinted amber (`#D97706`) or coral (`#E11D48`) when <48 hours remain.
  - **Status Pill:** Rounded-full pill with dot indicator (e.g., `#ECFDF5` background, `#047857` text, and `#10B981` solid dot for "Done").
- Features a quick-complete checkbox aligned top-left or trailing bottom-right.

### Action Buttons
- **Tactile Primary:** Solid `#4338CA` with an internal top bevel (`inset 0 1px 0 rgba(255,255,255,0.2)`) and bottom micro-shadow (`0 2px 0 #312E81`). On click/active: translates down 1px with reduced shadow for a physical click feeling.
- **Secondary (Outlined):** `#FFFFFF` fill, `#CBD5E1` border, `#334155` label text.
- **Urgent / Destructive:** `#E11D48` background with `#BE123C` bottom lip.

### Segmented Filters
- Encased in a recessed track (`#F1F5F9`) with 4px inner padding.
- Filter options feature equal horizontal padding, displaying task counts in muted mono tags (`#94A3B8`).
- The active segment transitions onto an elevated white pill (`#FFFFFF`) with Level 1 shadow and crisp `#0F172A` text.

### Checkboxes & Selection Controls
- Sized at 18px with `4px` border-radius.
- Unchecked: `#FFFFFF` fill with 1.5px `#CBD5E1` stroke.
- Checked: `#059669` emerald fill with a crisp white geometric checkmark and a spring scale-down animation (`transform: scale(0.92)`).

### Input Fields
- Structured with `#FFFFFF` background, 1px `#CBD5E1` border, and `0.5rem` corner radius.
- Focus state activates an indigo glow ring: `0 0 0 3px rgba(67, 56, 202, 0.15)` with border shifting to `#4338CA`.
- Prefix/Suffix tags (e.g., course prefix inputs or deadline time pickers) use `label-mono` styling within fixed slate-tinted inner caps.

### Priority & Status Badges
- **Overdue / Urgent:** `#FFF1F2` background, `#BE123C` text, `#FDA4AF` outline.
- **Pending / In Progress:** `#EEF2FF` background, `#4338CA` text, `#C7D2FE` outline.
- **Completed:** `#ECFDF5` background, `#047857` text, `#A7F3D0` outline.